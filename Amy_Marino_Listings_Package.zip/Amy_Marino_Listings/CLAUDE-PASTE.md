# Paste this into Claude Code

I have added a numbered real-estate listing asset package to this repository. Preserve the numbering and do not mix information or photos between properties.

Read `listing-details.json` as the authoritative structured data source. Each record includes its matching `photoFolder`. Copy or move the numbered property folders into the site's public assets directory, then generate the listing cards and property pages from the JSON rather than hard-coding the same information in multiple components.

Rules:

1. Properties 1 and 2 are current listings. Property 1 is for sale; property 2 is for rent.
2. Properties 3–6 are sold/off-market and must be displayed only in a Sold, Past Sales, or Portfolio section—not as active listings.
3. Property 4 has no supplied listing photographs. Do not use another property's image, AI imagery, or a generic stock house. Use an intentional branded placeholder until the agent supplies an authorized photo.
4. Keep each folder's image order. `01` is the cover image.
5. Use every available image in a responsive gallery with a fullscreen lightbox for the two active listings.
6. Do not invent facts. If a field is absent from `listing-details.json`, omit it or mark it for review.
7. Keep the existing Amy Marino site design system. Do not redesign unrelated sections.
8. Before publishing the images, confirm the agent or brokerage has the right to republish them on this site.

After implementation, report exactly which page or component uses each numbered listing and verify that sold properties are not labeled active.
