# Amy Marino listing assets

Numbering matches the URLs supplied by Brandon.

| # | Property | Status on source | Photos included |
|---|---|---|---:|
| 1 | 1109 Round Pointe Dr Unit 1109, Haverstraw, NY 10927 | Active, for sale | 23 |
| 2 | 25 Leroy Pl Apt 501, New Rochelle, NY 10805 | Active, for rent | 16 |
| 3 | 171 Van Etten Blvd, New Rochelle, NY 10804 | Sold/off market | 1 cover image |
| 4 | 142 Brook St Unit A, Scarsdale, NY 10583 | Sold/off market | 0 listing photos |
| 5 | 8 Homestead Ave, Scarsdale, NY 10583 | Sold/off market | 1 cover image |
| 6 | 701 Pelham Rd Apt 2E, New Rochelle, NY 10805 | Sold/off market | 1 cover image |

## Important implementation note

Properties 3–6 are sold/off-market pages, not current listings. They should be presented as past sales or portfolio properties if Amy confirms they are hers. Property 4 currently exposes only Google Street View on the supplied page, so no listing photo was included. The other sold Zillow pages expose only one cover image each through the supplied public pages.

Before publishing, confirm that Amy or her brokerage has permission to reuse every downloaded image on her personal website. Public visibility on Realtor.com or Zillow does not by itself establish republication rights.

`listing-details.json` contains structured data ready for Claude. The numbered property folders contain the matching images in source gallery order.

